Group 1

Instructions to build app: 
1) For MapKit, open mapKitPlayAround.xcodeproj
1a) Run the program using the simulator

2) For Firebase, open AreYouFree.xcworkspace
2a) Run the program using the simulator

3) For CloudKit, open Project Group 1.xcodeproj
3a) Open the simulator and ensure you're logged in to iCloud
3b) Run the program using the simulator


Description of how app was coded:
- Each program was run by performing simple read/write operations for CloudKit and Firebase, and MapKit simply displays the location of SJSU using global coordinates