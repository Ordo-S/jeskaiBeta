//
//  Contact.swift
//  contacts
//
//  Created by Little Buddy on 11/4/18.
//  Copyright © 2018 Michael Wang. All rights reserved.
//

import Foundation

struct Contact {
    let name: String
    let username: String
}
