# Are you free V2 

Whats up, bassically i nuked the whole code base on 11/7 beacuse it was hot garbage and needed to be started over. Will try to activly commit new chages this time

