//
//  ViewController.swift
//  invite
//
//  Created by Little Buddy on 11/21/18.
//  Copyright © 2018 Michael Wang. All rights reserved.
//

import UIKit

class InviteViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

