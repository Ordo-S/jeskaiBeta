//
//  InviteRequest.swift
//  invite
//
//  Created by Little Buddy on 11/21/18.
//  Copyright © 2018 Michael Wang. All rights reserved.
//

import Foundation

struct InviteRequest {
    let name: String
    let accepted: Bool
}


